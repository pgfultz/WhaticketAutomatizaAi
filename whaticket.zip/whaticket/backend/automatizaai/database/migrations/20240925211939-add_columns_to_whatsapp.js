'use strict';
module.exports = {
    up: async (queryInterface, Sequelize) => {
        const tableInfo = await queryInterface.describeTable('Whatsapps');
        if (!tableInfo.importOldMessages) {
            await queryInterface.addColumn('Whatsapps', 'importOldMessages', {
                type: Sequelize.DATE,
                allowNull: true,
            });
        }
        if (!tableInfo.importRecentMessages) {
            await queryInterface.addColumn('Whatsapps', 'importRecentMessages', {
                type: Sequelize.DATE,
                allowNull: true,
            });
        }
        if (!tableInfo.statusImportMessages) {
            await queryInterface.addColumn('Whatsapps', 'statusImportMessages', {
                type: Sequelize.STRING,
                allowNull: true,
            });
        }
        if (!tableInfo.closedTicketsPostImported) {
            await queryInterface.addColumn('Whatsapps', 'closedTicketsPostImported', {
                type: Sequelize.BOOLEAN,
                allowNull: true,
                defaultValue: false,
            });
        }
        if (!tableInfo.importOldMessagesGroups) {
            await queryInterface.addColumn('Whatsapps', 'importOldMessagesGroups', {
                type: Sequelize.BOOLEAN,
                allowNull: true,
                defaultValue: false,
            });
        }
    },
    down: async (queryInterface) => {
        await queryInterface.removeColumn('Whatsapps', 'importOldMessages');
        await queryInterface.removeColumn('Whatsapps', 'importRecentMessages');
        await queryInterface.removeColumn('Whatsapps', 'statusImportMessages');
        await queryInterface.removeColumn('Whatsapps', 'closedTicketsPostImported');
        await queryInterface.removeColumn('Whatsapps', 'importOldMessagesGroups');
    }
};
